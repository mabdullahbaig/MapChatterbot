
Test prompts on given data after uplpoad 
USA

Hi, describe the data and what are exact field in this data

Can you help me generating a heat map of density from this data

Generate the interactive choropleth map of PRECIPITAT

make density map and calculate statistics

NYC

describe this new york data

- Make a static map for new york city using New_York_C field

- Cool, make a new map of New_York_C this time use color scheme reds move legend to bottom right legend size small and add title NYC Population 2010

- make a new map of New_York_C this time use color scheme purples move legend to bottom right legend size small and add - title NYC Population 2010 - legend title Legend

PAKISTAN


Make a choropleth map of POPULATION, color scheme blues, place legend to bottom right add title Population of Pakistan 2015